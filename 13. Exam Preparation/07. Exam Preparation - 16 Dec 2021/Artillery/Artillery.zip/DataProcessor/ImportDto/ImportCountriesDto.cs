﻿
using System.ComponentModel.DataAnnotations;


namespace Artillery.DataProcessor.ImportDto
{
    public class ImportCountriesDto
    {
        [Required]
        public int Id { get; set; }
    }
}

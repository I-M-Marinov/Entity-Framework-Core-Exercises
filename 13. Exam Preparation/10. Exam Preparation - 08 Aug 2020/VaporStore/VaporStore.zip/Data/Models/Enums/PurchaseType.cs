﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaporStore.Data.Models.Enums
{
    public enum PurchaseType
    {
        Retail = 0,
        Digital = 1,
    }
}

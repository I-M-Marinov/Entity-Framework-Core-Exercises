﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server= MARINOV-GAME-PC\SQLEXPRESS; Database = VaporStore; Integrated Security = True; Encrypt = False; TrustServerCertificate = True;";
    }
}

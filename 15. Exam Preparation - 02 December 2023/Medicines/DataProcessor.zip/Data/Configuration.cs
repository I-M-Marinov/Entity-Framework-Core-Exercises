﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server= MARINOV-GAME-PC\SQLEXPRESS; Database = Medicines; Integrated Security = True; Encrypt = False; TrustServerCertificate = True;";
    }
}

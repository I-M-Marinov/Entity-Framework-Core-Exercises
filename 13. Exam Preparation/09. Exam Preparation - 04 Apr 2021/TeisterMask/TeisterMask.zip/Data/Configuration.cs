﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server= MARINOV-GAME-PC\SQLEXPRESS; Database = TeisterMask; Integrated Security = True; Encrypt = False; TrustServerCertificate = True;";
    }
}


﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server= MARINOV-GAME-PC\SQLEXPRESS; Database = ProductShop; Integrated Security = True; Encrypt = False; TrustServerCertificate = True;";

        // My laptop's SQL server ConnectionString = @"Server=.;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
 
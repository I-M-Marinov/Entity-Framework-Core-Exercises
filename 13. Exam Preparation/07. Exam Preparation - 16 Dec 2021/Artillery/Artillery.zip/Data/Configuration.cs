﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server= MARINOV-GAME-PC\SQLEXPRESS; Database = Artillery; Integrated Security = True; Encrypt = False; TrustServerCertificate = True;";
    }
}

